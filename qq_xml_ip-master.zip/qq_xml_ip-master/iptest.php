<head>
	<meta itemprop="name" content="xml卡片标题" />
	<meta itemprop="description" content="xml卡片描述" />
	<meta itemprop="image" content="iptest.php文件链接?id=<?php echo $_GET["id"]; ?>" />   //此处注意链接带上参数id
	<title>标题</title>
</head>
